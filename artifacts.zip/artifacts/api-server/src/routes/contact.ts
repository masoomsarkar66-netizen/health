import { Router, type IRouter } from "express";
import { db, contactsTable } from "@workspace/db";
import { desc } from "drizzle-orm";
import { SubmitContactBody } from "@workspace/api-zod";

const router: IRouter = Router();

router.post("/contact", async (req, res): Promise<void> => {
  const parsed = SubmitContactBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  await db.insert(contactsTable).values(parsed.data);

  res.json({ success: true, message: "Thank you for your message. We will get back to you soon." });
});

export default router;
