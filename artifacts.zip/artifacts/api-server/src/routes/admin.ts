import { Router, type IRouter } from "express";
import { db, contactsTable, blogPostsTable, cbcAnalysesTable } from "@workspace/db";
import { eq, sql, desc } from "drizzle-orm";

const router: IRouter = Router();

router.get("/admin/contacts", async (_req, res): Promise<void> => {
  const contacts = await db.select().from(contactsTable).orderBy(desc(contactsTable.createdAt));
  res.json(contacts.map(c => ({
    ...c,
    createdAt: c.createdAt.toISOString(),
  })));
});

router.get("/admin/dashboard", async (_req, res): Promise<void> => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const [totalAnalyses] = await db.select({ count: sql<number>`count(*)::int` }).from(cbcAnalysesTable);
  const [todayAnalyses] = await db.select({ count: sql<number>`count(*)::int` }).from(cbcAnalysesTable).where(sql`created_at >= ${today}`);
  const [totalBlogPosts] = await db.select({ count: sql<number>`count(*)::int` }).from(blogPostsTable);
  const [publishedPosts] = await db.select({ count: sql<number>`count(*)::int` }).from(blogPostsTable).where(eq(blogPostsTable.published, true));
  const [totalContacts] = await db.select({ count: sql<number>`count(*)::int` }).from(contactsTable);

  // Count contacts from last 7 days as "unread"
  const sevenDaysAgo = new Date();
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
  const [unreadContacts] = await db.select({ count: sql<number>`count(*)::int` }).from(contactsTable).where(sql`created_at >= ${sevenDaysAgo}`);

  // Recent analyses (last 7 days)
  const [recentAnalyses] = await db.select({ count: sql<number>`count(*)::int` }).from(cbcAnalysesTable).where(sql`created_at >= ${sevenDaysAgo}`);

  // Popular categories
  const popularCategories = await db
    .select({
      category: blogPostsTable.category,
      count: sql<number>`count(*)::int`,
    })
    .from(blogPostsTable)
    .groupBy(blogPostsTable.category)
    .orderBy(desc(sql`count(*)`))
    .limit(5);

  res.json({
    totalAnalyses: totalAnalyses?.count ?? 0,
    todayAnalyses: todayAnalyses?.count ?? 0,
    totalBlogPosts: totalBlogPosts?.count ?? 0,
    publishedPosts: publishedPosts?.count ?? 0,
    totalContacts: totalContacts?.count ?? 0,
    unreadContacts: unreadContacts?.count ?? 0,
    recentAnalyses: recentAnalyses?.count ?? 0,
    popularCategories,
  });
});

export default router;
