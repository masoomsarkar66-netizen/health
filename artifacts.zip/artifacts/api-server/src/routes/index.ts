import { Router, type IRouter } from "express";
import healthRouter from "./health";
import cbcRouter from "./cbc";
import blogRouter from "./blog";
import contactRouter from "./contact";
import adminRouter from "./admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(cbcRouter);
router.use(blogRouter);
router.use(contactRouter);
router.use(adminRouter);

export default router;
