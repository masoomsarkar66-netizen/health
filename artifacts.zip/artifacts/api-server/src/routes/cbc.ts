import { Router, type IRouter } from "express";
import { db, cbcAnalysesTable, blogPostsTable, contactsTable } from "@workspace/db";
import { sql } from "drizzle-orm";
import { InterpretCbcBody } from "@workspace/api-zod";
import OpenAI from "openai";
import { logger } from "../lib/logger";

const router: IRouter = Router();

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

function getNormalRange(param: string, gender: string): { min: number; max: number; unit: string } {
  type GenderedRange = { male: { min: number; max: number }; female: { min: number; max: number }; unit: string };
  type SimpleRange = { min: number; max: number; unit: string };

  const ranges: Record<string, GenderedRange | SimpleRange> = {
    hemoglobin: { male: { min: 13.5, max: 17.5 }, female: { min: 12.0, max: 15.5 }, unit: "g/dL" },
    rbc: { male: { min: 4.5, max: 5.9 }, female: { min: 4.1, max: 5.1 }, unit: "M/μL" },
    wbc: { min: 4.5, max: 11.0, unit: "K/μL" },
    platelets: { min: 150, max: 400, unit: "K/μL" },
    hematocrit: { male: { min: 41, max: 53 }, female: { min: 36, max: 46 }, unit: "%" },
    mcv: { min: 80, max: 100, unit: "fL" },
    mch: { min: 27, max: 33, unit: "pg" },
    mchc: { min: 32, max: 36, unit: "g/dL" },
    rdw: { min: 11.5, max: 14.5, unit: "%" },
    neutrophils: { min: 50, max: 70, unit: "%" },
    lymphocytes: { min: 20, max: 40, unit: "%" },
    monocytes: { min: 2, max: 8, unit: "%" },
    eosinophils: { min: 1, max: 4, unit: "%" },
    basophils: { min: 0.5, max: 1.0, unit: "%" },
    esr: { male: { min: 0, max: 15 }, female: { min: 0, max: 20 }, unit: "mm/hr" },
  };

  const range = ranges[param];
  if (!range) return { min: 0, max: 0, unit: "" };
  if ("male" in range) {
    const gendered = gender === "female" ? range.female : range.male;
    return { min: gendered.min, max: gendered.max, unit: range.unit };
  }
  return { min: range.min, max: range.max, unit: range.unit };
}

router.post("/cbc/interpret", async (req, res): Promise<void> => {
  const parsed = InterpretCbcBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const data = parsed.data;

  const paramNames = ["hemoglobin", "rbc", "wbc", "platelets", "hematocrit", "mcv", "mch", "mchc", "rdw", "neutrophils", "lymphocytes", "monocytes", "eosinophils", "basophils", "esr"] as const;

  const providedParams = paramNames.filter(p => data[p] != null);

  const paramSummary = providedParams.map(p => {
    const range = getNormalRange(p, data.gender);
    const value = data[p] as number;
    return `${p}: ${value} ${range.unit} (normal: ${range.min}-${range.max})`;
  }).join("\n");

  const prompt = `You are a medical education assistant helping patients understand their Complete Blood Count (CBC) report. You do NOT provide medical diagnosis or treatment advice.

Patient information:
- Age: ${data.age}
- Gender: ${data.gender}

CBC values provided:
${paramSummary}

Provide a comprehensive educational interpretation in the following JSON format exactly:
{
  "overallSummary": "2-3 sentence plain English summary of the overall CBC picture",
  "normalFindings": ["list of parameters that are within normal range, each as a descriptive sentence"],
  "abnormalFindings": [
    {
      "parameter": "parameter name",
      "value": numeric_value,
      "normalRange": "min-max unit",
      "status": "high" or "low",
      "explanation": "plain English explanation of what this means"
    }
  ],
  "parameterExplanations": [
    {
      "parameter": "parameter name",
      "value": numeric_value or null,
      "normalRange": "min-max unit",
      "status": "normal" or "high" or "low" or "not_provided",
      "explanation": "what this parameter measures",
      "clinicalSignificance": "what an abnormal result might suggest educationally"
    }
  ],
  "clinicalSignificance": "Educational overview of possible conditions suggested by these results (not diagnosis)",
  "lifestyleRecommendations": ["general wellness tips relevant to the findings"],
  "doctorQuestions": ["questions the patient should ask their doctor"],
  "disclaimer": "This interpretation is for educational purposes only and does not constitute medical advice, diagnosis, or treatment. Always consult a qualified healthcare professional for medical decisions."
}

Be empathetic, clear, and educational. Use simple language. Do not diagnose.`;

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-5-mini",
      max_completion_tokens: 4096,
      messages: [
        { role: "system", content: "You are a helpful medical education assistant. Always respond with valid JSON only, no markdown code blocks." },
        { role: "user", content: prompt },
      ],
    });

    const responseText = completion.choices[0]?.message?.content ?? "{}";
    let interpretation: unknown;
    try {
      interpretation = JSON.parse(responseText);
    } catch {
      req.log.error({ responseText }, "Failed to parse AI response as JSON");
      res.status(500).json({ error: "Failed to parse AI response" });
      return;
    }

    // Save to DB
    await db.insert(cbcAnalysesTable).values({
      age: data.age,
      gender: data.gender,
      hemoglobin: data.hemoglobin ?? undefined,
      rbc: data.rbc ?? undefined,
      wbc: data.wbc ?? undefined,
      platelets: data.platelets ?? undefined,
      hematocrit: data.hematocrit ?? undefined,
      mcv: data.mcv ?? undefined,
      mch: data.mch ?? undefined,
      mchc: data.mchc ?? undefined,
      rdw: data.rdw ?? undefined,
      neutrophils: data.neutrophils ?? undefined,
      lymphocytes: data.lymphocytes ?? undefined,
      monocytes: data.monocytes ?? undefined,
      eosinophils: data.eosinophils ?? undefined,
      basophils: data.basophils ?? undefined,
      esr: data.esr ?? undefined,
      resultJson: responseText,
    });

    res.json(interpretation);
  } catch (err) {
    req.log.error({ err }, "OpenAI API error");
    res.status(500).json({ error: "AI interpretation failed" });
  }
});

router.get("/cbc/stats", async (_req, res): Promise<void> => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const [totalAnalyses] = await db.select({ count: sql<number>`count(*)::int` }).from(cbcAnalysesTable);
  const [todayAnalyses] = await db.select({ count: sql<number>`count(*)::int` }).from(cbcAnalysesTable).where(sql`created_at >= ${today}`);
  const [blogCount] = await db.select({ count: sql<number>`count(*)::int` }).from(blogPostsTable);
  const [contactCount] = await db.select({ count: sql<number>`count(*)::int` }).from(contactsTable);

  res.json({
    totalAnalyses: totalAnalyses?.count ?? 0,
    todayAnalyses: todayAnalyses?.count ?? 0,
    totalBlogPosts: blogCount?.count ?? 0,
    totalContacts: contactCount?.count ?? 0,
  });
});

export default router;
