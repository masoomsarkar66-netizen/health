import { Router, type IRouter } from "express";
import { db, blogPostsTable, blogCategoriesTable } from "@workspace/db";
import { eq, ilike, sql, desc } from "drizzle-orm";
import {
  CreateBlogPostBody,
  UpdateBlogPostBody,
  UpdateBlogPostParams,
  DeleteBlogPostParams,
  GetBlogPostParams,
  GetBlogPostsQueryParams,
  CreateBlogCategoryBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/blog/posts", async (req, res): Promise<void> => {
  const queryParsed = GetBlogPostsQueryParams.safeParse(req.query);
  if (!queryParsed.success) {
    res.status(400).json({ error: queryParsed.error.message });
    return;
  }
  const { category, search, limit = 10, offset = 0, featured } = queryParsed.data;

  let query = db.select().from(blogPostsTable).$dynamic();

  if (category) {
    query = query.where(eq(blogPostsTable.category, category));
  }
  if (search) {
    query = query.where(ilike(blogPostsTable.title, `%${search}%`));
  }
  if (featured !== undefined) {
    query = query.where(eq(blogPostsTable.featured, featured));
  }

  const [countResult] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(blogPostsTable)
    .where(
      category
        ? eq(blogPostsTable.category, category)
        : search
        ? ilike(blogPostsTable.title, `%${search}%`)
        : sql`true`
    );

  const posts = await query
    .orderBy(desc(blogPostsTable.createdAt))
    .limit(limit)
    .offset(offset);

  res.json({
    posts: posts.map(p => ({
      ...p,
      createdAt: p.createdAt.toISOString(),
      updatedAt: p.updatedAt.toISOString(),
    })),
    total: countResult?.count ?? 0,
  });
});

router.post("/blog/posts", async (req, res): Promise<void> => {
  const parsed = CreateBlogPostBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [post] = await db.insert(blogPostsTable).values(parsed.data).returning();
  res.status(201).json({
    ...post,
    createdAt: post.createdAt.toISOString(),
    updatedAt: post.updatedAt.toISOString(),
  });
});

router.get("/blog/posts/:id", async (req, res): Promise<void> => {
  const params = GetBlogPostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [post] = await db.select().from(blogPostsTable).where(eq(blogPostsTable.id, params.data.id));
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  res.json({
    ...post,
    createdAt: post.createdAt.toISOString(),
    updatedAt: post.updatedAt.toISOString(),
  });
});

router.patch("/blog/posts/:id", async (req, res): Promise<void> => {
  const params = UpdateBlogPostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateBlogPostBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [post] = await db
    .update(blogPostsTable)
    .set(parsed.data)
    .where(eq(blogPostsTable.id, params.data.id))
    .returning();

  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  res.json({
    ...post,
    createdAt: post.createdAt.toISOString(),
    updatedAt: post.updatedAt.toISOString(),
  });
});

router.delete("/blog/posts/:id", async (req, res): Promise<void> => {
  const params = DeleteBlogPostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [post] = await db.delete(blogPostsTable).where(eq(blogPostsTable.id, params.data.id)).returning();
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  res.sendStatus(204);
});

router.get("/blog/categories", async (_req, res): Promise<void> => {
  const categories = await db.select().from(blogCategoriesTable).orderBy(blogCategoriesTable.name);

  const withCounts = await Promise.all(
    categories.map(async (cat) => {
      const [countResult] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(blogPostsTable)
        .where(eq(blogPostsTable.category, cat.slug));
      return {
        id: cat.id,
        name: cat.name,
        slug: cat.slug,
        postCount: countResult?.count ?? 0,
      };
    })
  );

  res.json(withCounts);
});

router.post("/blog/categories", async (req, res): Promise<void> => {
  const parsed = CreateBlogCategoryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [category] = await db.insert(blogCategoriesTable).values(parsed.data).returning();
  const [countResult] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(blogPostsTable)
    .where(eq(blogPostsTable.category, category.slug));

  res.status(201).json({
    id: category.id,
    name: category.name,
    slug: category.slug,
    postCount: countResult?.count ?? 0,
  });
});

router.get("/blog/featured", async (_req, res): Promise<void> => {
  const posts = await db
    .select()
    .from(blogPostsTable)
    .where(eq(blogPostsTable.featured, true))
    .orderBy(desc(blogPostsTable.createdAt))
    .limit(6);

  res.json(posts.map(p => ({
    ...p,
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt.toISOString(),
  })));
});

export default router;
