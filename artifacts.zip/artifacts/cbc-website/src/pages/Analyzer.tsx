import { AppLayout } from "@/components/layout/AppLayout";
import { SEOHead } from "@/components/SEOHead";
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useInterpretCbc } from "@workspace/api-client-react";
import type { CbcInterpretation, AbnormalFinding, ParameterExplanation } from "@workspace/api-zod";
import { UploadCloud, FileText, FileImage, Activity, CheckCircle, AlertTriangle, AlertCircle, Info, Download, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

const cbcSchema = z.object({
  age: z.coerce.number().min(1, "Age must be at least 1").max(120, "Age must be less than 120"),
  gender: z.enum(["male", "female", "other"]),
  hemoglobin: z.coerce.number().optional(),
  rbc: z.coerce.number().optional(),
  wbc: z.coerce.number().optional(),
  platelets: z.coerce.number().optional(),
  hematocrit: z.coerce.number().optional(),
  mcv: z.coerce.number().optional(),
  mch: z.coerce.number().optional(),
  mchc: z.coerce.number().optional(),
  rdw: z.coerce.number().optional(),
  neutrophils: z.coerce.number().optional(),
  lymphocytes: z.coerce.number().optional(),
  monocytes: z.coerce.number().optional(),
  eosinophils: z.coerce.number().optional(),
  basophils: z.coerce.number().optional(),
  esr: z.coerce.number().optional(),
});

type CbcFormValues = z.infer<typeof cbcSchema>;

export default function Analyzer() {
  const [activeTab, setActiveTab] = useState("manual");
  const interpretMutation = useInterpretCbc();
  const [interpretation, setInterpretation] = useState<CbcInterpretation | null>(null);

  const form = useForm<CbcFormValues>({
    resolver: zodResolver(cbcSchema),
    defaultValues: {
      gender: "male",
    },
  });

  const onSubmit = (data: CbcFormValues) => {
    interpretMutation.mutate({ data: data as any }, {
      onSuccess: (res) => {
        setInterpretation(res);
        setTimeout(() => {
          document.getElementById('results-section')?.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      }
    });
  };

  const getStatusBadge = (status: string) => {
    if (status === 'high') return <Badge variant="destructive" className="bg-red-500 hover:bg-red-600"><AlertTriangle className="w-3 h-3 mr-1" /> High</Badge>;
    if (status === 'low') return <Badge variant="default" className="bg-yellow-500 hover:bg-yellow-600 text-yellow-950"><AlertCircle className="w-3 h-3 mr-1" /> Low</Badge>;
    if (status === 'normal') return <Badge variant="default" className="bg-green-500 hover:bg-green-600 text-white"><CheckCircle className="w-3 h-3 mr-1" /> Normal</Badge>;
    return <Badge variant="secondary">Not Provided</Badge>;
  };

  return (
    <AppLayout>
      <SEOHead
        title="CBC Analyzer — Enter Your Blood Test Values"
        description="Analyze your Complete Blood Count manually or upload your lab report. Get instant clinical interpretation of hemoglobin, WBC, platelets, RBC, MCV, and 15+ CBC parameters."
        canonical="/analyzer"
        keywords="CBC analyzer, blood test analyzer, hemoglobin analyzer, WBC count interpreter, platelet count analysis, CBC values normal range, lab report interpreter"
      />
      <div className="bg-muted/30 py-12 border-b">
        <div className="container mx-auto px-4 max-w-4xl text-center">
          <h1 className="text-4xl font-bold mb-4">CBC Analyzer</h1>
          <p className="text-xl text-muted-foreground">
            Enter your lab results or upload your report to receive a clinical interpretation in plain English.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12 max-w-5xl">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-12">
          <TabsList className="grid w-full grid-cols-3 mb-8 h-12">
            <TabsTrigger value="manual" className="text-base h-full"><Activity className="w-4 h-4 mr-2" /> Manual Entry</TabsTrigger>
            <TabsTrigger value="pdf" className="text-base h-full"><FileText className="w-4 h-4 mr-2" /> PDF Upload</TabsTrigger>
            <TabsTrigger value="image" className="text-base h-full"><FileImage className="w-4 h-4 mr-2" /> Image Upload</TabsTrigger>
          </TabsList>
          
          <TabsContent value="manual">
            <Card>
              <CardHeader>
                <CardTitle>Enter CBC Values</CardTitle>
                <CardDescription>Fill in as many fields as you have available from your lab report.</CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-muted/50 p-6 rounded-lg border border-border/50">
                      <FormField
                        control={form.control}
                        name="age"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Age</FormLabel>
                            <FormControl>
                              <Input type="number" placeholder="e.g. 35" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="gender"
                        render={({ field }) => (
                          <FormItem className="space-y-3">
                            <FormLabel>Biological Sex</FormLabel>
                            <FormControl>
                              <RadioGroup
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                                className="flex space-x-4"
                              >
                                <FormItem className="flex items-center space-x-2 space-y-0">
                                  <FormControl>
                                    <RadioGroupItem value="male" />
                                  </FormControl>
                                  <FormLabel className="font-normal cursor-pointer">Male</FormLabel>
                                </FormItem>
                                <FormItem className="flex items-center space-x-2 space-y-0">
                                  <FormControl>
                                    <RadioGroupItem value="female" />
                                  </FormControl>
                                  <FormLabel className="font-normal cursor-pointer">Female</FormLabel>
                                </FormItem>
                                <FormItem className="flex items-center space-x-2 space-y-0">
                                  <FormControl>
                                    <RadioGroupItem value="other" />
                                  </FormControl>
                                  <FormLabel className="font-normal cursor-pointer">Other</FormLabel>
                                </FormItem>
                              </RadioGroup>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                      <FormField control={form.control} name="hemoglobin" render={({ field }) => (
                        <FormItem><FormLabel>Hemoglobin (g/dL)</FormLabel><FormControl><Input type="number" step="0.1" placeholder="e.g. 14.2" {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="rbc" render={({ field }) => (
                        <FormItem><FormLabel>RBC (M/μL)</FormLabel><FormControl><Input type="number" step="0.01" placeholder="e.g. 4.8" {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="wbc" render={({ field }) => (
                        <FormItem><FormLabel>WBC (/μL)</FormLabel><FormControl><Input type="number" placeholder="e.g. 6500" {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="platelets" render={({ field }) => (
                        <FormItem><FormLabel>Platelets (/μL)</FormLabel><FormControl><Input type="number" placeholder="e.g. 250000" {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="hematocrit" render={({ field }) => (
                        <FormItem><FormLabel>Hematocrit (%)</FormLabel><FormControl><Input type="number" step="0.1" placeholder="e.g. 42.5" {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="mcv" render={({ field }) => (
                        <FormItem><FormLabel>MCV (fL)</FormLabel><FormControl><Input type="number" step="0.1" placeholder="e.g. 90" {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="mch" render={({ field }) => (
                        <FormItem><FormLabel>MCH (pg)</FormLabel><FormControl><Input type="number" step="0.1" placeholder="e.g. 29" {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="mchc" render={({ field }) => (
                        <FormItem><FormLabel>MCHC (g/dL)</FormLabel><FormControl><Input type="number" step="0.1" placeholder="e.g. 34" {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="rdw" render={({ field }) => (
                        <FormItem><FormLabel>RDW (%)</FormLabel><FormControl><Input type="number" step="0.1" placeholder="e.g. 13.5" {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="neutrophils" render={({ field }) => (
                        <FormItem><FormLabel>Neutrophils (%)</FormLabel><FormControl><Input type="number" step="0.1" placeholder="e.g. 60" {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="lymphocytes" render={({ field }) => (
                        <FormItem><FormLabel>Lymphocytes (%)</FormLabel><FormControl><Input type="number" step="0.1" placeholder="e.g. 30" {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="monocytes" render={({ field }) => (
                        <FormItem><FormLabel>Monocytes (%)</FormLabel><FormControl><Input type="number" step="0.1" placeholder="e.g. 5" {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="eosinophils" render={({ field }) => (
                        <FormItem><FormLabel>Eosinophils (%)</FormLabel><FormControl><Input type="number" step="0.1" placeholder="e.g. 2" {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="basophils" render={({ field }) => (
                        <FormItem><FormLabel>Basophils (%)</FormLabel><FormControl><Input type="number" step="0.1" placeholder="e.g. 0.5" {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="esr" render={({ field }) => (
                        <FormItem><FormLabel>ESR (mm/hr)</FormLabel><FormControl><Input type="number" placeholder="e.g. 15" {...field} /></FormControl><FormMessage /></FormItem>
                      )} />
                    </div>

                    <div className="pt-6">
                      <Button type="submit" size="lg" className="w-full md:w-auto h-12 px-8 text-lg" disabled={interpretMutation.isPending}>
                        {interpretMutation.isPending ? (
                          <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> Processing Analysis...</>
                        ) : (
                          <><Activity className="mr-2 h-5 w-5" /> Analyze Results</>
                        )}
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="pdf">
            <Card>
              <CardContent className="p-16 flex flex-col items-center justify-center border-2 border-dashed border-border/60 rounded-lg text-center bg-muted/20">
                <div className="w-20 h-20 bg-primary/10 text-primary rounded-full flex items-center justify-center mb-6">
                  <UploadCloud className="w-10 h-10" />
                </div>
                <h3 className="text-2xl font-semibold mb-2">Upload PDF Report</h3>
                <p className="text-muted-foreground max-w-md mb-8">
                  Upload your laboratory PDF document directly. Our system will extract the relevant CBC parameters automatically.
                </p>
                <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary/5">
                  Select PDF File
                </Button>
                <p className="text-xs text-muted-foreground mt-4">Feature coming soon</p>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="image">
            <Card>
              <CardContent className="p-16 flex flex-col items-center justify-center border-2 border-dashed border-border/60 rounded-lg text-center bg-muted/20">
                <div className="w-20 h-20 bg-primary/10 text-primary rounded-full flex items-center justify-center mb-6">
                  <FileImage className="w-10 h-10" />
                </div>
                <h3 className="text-2xl font-semibold mb-2">Upload Photo</h3>
                <p className="text-muted-foreground max-w-md mb-8">
                  Take a clear picture of your printed lab report. We'll use optical character recognition to extract the values.
                </p>
                <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary/5">
                  Choose Image
                </Button>
                <p className="text-xs text-muted-foreground mt-4">Feature coming soon</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {interpretMutation.isPending && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="my-16 text-center"
          >
            <div className="inline-block relative">
              <div className="w-24 h-24 border-4 border-primary/20 rounded-full border-t-primary animate-spin"></div>
              <Activity className="w-8 h-8 text-primary absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
            </div>
            <h3 className="text-2xl font-semibold mt-6 mb-2">Analyzing your results</h3>
            <p className="text-muted-foreground">Our clinical engine is cross-referencing your values with hematology guidelines...</p>
          </motion.div>
        )}

        <AnimatePresence>
          {interpretation && !interpretMutation.isPending && (
            <motion.div
              id="results-section"
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="mt-16 space-y-8"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <h2 className="text-3xl font-bold">Analysis Results</h2>
                <Button variant="outline"><Download className="w-4 h-4 mr-2" /> Download Report</Button>
              </div>

              <Card className="border-primary/20 shadow-lg shadow-primary/5">
                <CardHeader className="bg-primary/5 pb-4 border-b">
                  <CardTitle className="flex items-center text-2xl">
                    <Activity className="w-6 h-6 mr-3 text-primary" />
                    Overall Summary
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <p className="text-lg leading-relaxed">{interpretation.overallSummary}</p>
                </CardContent>
              </Card>

              {interpretation.abnormalFindings.length > 0 && (
                <Card className="border-destructive/20 shadow-lg shadow-destructive/5">
                  <CardHeader className="bg-destructive/5 pb-4 border-b">
                    <CardTitle className="flex items-center text-xl text-destructive">
                      <AlertTriangle className="w-5 h-5 mr-3" />
                      Attention Needed
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-6 space-y-6">
                    {interpretation.abnormalFindings.map((finding: AbnormalFinding, idx: number) => (
                      <div key={idx} className="flex flex-col md:flex-row gap-4 md:gap-8">
                        <div className="md:w-1/3 shrink-0">
                          <h4 className="font-semibold text-lg">{finding.parameter}</h4>
                          <div className="flex items-center gap-3 mt-2">
                            <span className="text-2xl font-bold">{finding.value}</span>
                            {getStatusBadge(finding.status)}
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">Normal: {finding.normalRange}</p>
                        </div>
                        <div className="md:w-2/3 bg-muted/30 p-4 rounded-lg">
                          <p>{finding.explanation}</p>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              )}

              <Card>
                <CardHeader>
                  <CardTitle>Parameter Breakdown</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="divide-y">
                    {interpretation.parameterExplanations.map((param: ParameterExplanation, idx: number) => (
                      <div key={idx} className="p-6 flex flex-col lg:flex-row gap-6 hover:bg-muted/10 transition-colors">
                        <div className="lg:w-1/4 shrink-0">
                          <h4 className="font-semibold">{param.parameter}</h4>
                          <div className="flex items-center gap-3 mt-1 mb-1">
                            {param.value !== null && <span className="font-mono">{param.value}</span>}
                            {getStatusBadge(param.status)}
                          </div>
                          <p className="text-xs text-muted-foreground">Range: {param.normalRange}</p>
                        </div>
                        <div className="lg:w-3/4 space-y-4">
                          <div>
                            <span className="text-sm font-semibold uppercase tracking-wider text-muted-foreground block mb-1">What it means</span>
                            <p className="text-sm">{param.explanation}</p>
                          </div>
                          <div>
                            <span className="text-sm font-semibold uppercase tracking-wider text-muted-foreground block mb-1">Clinical Significance</span>
                            <p className="text-sm">{param.clinicalSignificance}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <Card className="bg-primary/5 border-primary/10">
                  <CardHeader>
                    <CardTitle className="text-xl">Lifestyle Recommendations</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {interpretation.lifestyleRecommendations.map((rec: string, idx: number) => (
                        <li key={idx} className="flex gap-3">
                          <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />
                          <span>{rec}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
                <Card className="bg-secondary/20">
                  <CardHeader>
                    <CardTitle className="text-xl">Questions for your Doctor</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {interpretation.doctorQuestions.map((q: string, idx: number) => (
                        <li key={idx} className="flex gap-3">
                          <div className="w-1.5 h-1.5 rounded-full bg-foreground/60 mt-2 shrink-0" />
                          <span className="font-medium">{q}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </div>

              <div className="bg-muted p-6 rounded-lg text-sm text-muted-foreground flex gap-4 mt-12">
                <Info className="w-6 h-6 shrink-0 text-primary" />
                <p>{interpretation.disclaimer}</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </AppLayout>
  );
}
