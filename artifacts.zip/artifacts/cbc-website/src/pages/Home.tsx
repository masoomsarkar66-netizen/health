import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { AppLayout } from "@/components/layout/AppLayout";
import { SEOHead } from "@/components/SEOHead";
import { Card, CardContent } from "@/components/ui/card";
import { FileText, Brain, HeartPulse, ChevronRight, Activity, Upload, CheckCircle } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { motion } from "framer-motion";

const PARAMETERS = [
  { name: "Hemoglobin (Hb)", range: "M: 13.5–17.5 g/dL, F: 12–15.5 g/dL", purpose: "Oxygen transport" },
  { name: "RBC", range: "M: 4.5–5.9 M/μL, F: 4.1–5.1 M/μL", purpose: "Red cell count" },
  { name: "WBC", range: "4,500–11,000 /μL", purpose: "Immune defense" },
  { name: "Platelet", range: "150,000–400,000 /μL", purpose: "Clotting" },
  { name: "HCT", range: "M: 41–53%, F: 36–46%", purpose: "Blood volume ratio" },
  { name: "MCV", range: "80–100 fL", purpose: "Red cell size" },
  { name: "MCH", range: "27–33 pg", purpose: "Hemoglobin per cell" },
  { name: "MCHC", range: "32–36 g/dL", purpose: "Hemoglobin concentration" },
];

export default function Home() {
  return (
    <AppLayout>
      <SEOHead
        title="Understand Your CBC Blood Test Results Instantly"
        description="Enter your Complete Blood Count (CBC) values and get a clear, plain-English clinical interpretation grounded in standard hematology guidelines. Free CBC report analyzer."
        canonical="/"
        keywords="CBC report interpretation, complete blood count analyzer, CBC test results explained, hemoglobin levels, WBC count, blood test results, hematology guidelines"
      />
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-slate-50 dark:bg-slate-900 pt-16 md:pt-24 lg:pt-32 pb-16">
        <div className="container mx-auto px-4 relative z-10 text-center max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6 border border-primary/20">
              <Activity className="w-4 h-4" />
              <span>Smart Clinical Analysis</span>
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-7xl font-extrabold tracking-tight text-foreground mb-6 leading-tight">
              Understand your blood test results. <span className="text-primary">Instantly.</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto">
              Upload your Complete Blood Count (CBC) report and receive a clear, clinical interpretation grounded in standard hematology guidelines. No more guessing what "MCV High" means.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/analyzer">
                <Button size="lg" className="w-full sm:w-auto text-lg h-14 px-8 shadow-xl shadow-primary/20">
                  Analyze My Report
                  <ChevronRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <a href="#how-it-works" className="w-full sm:w-auto">
                <Button size="lg" variant="outline" className="w-full sm:w-auto text-lg h-14 px-8 border-border hover:bg-secondary">
                  How it Works
                </Button>
              </a>
            </div>
          </motion.div>
        </div>
        
        {/* Decorative background elements */}
        <div className="absolute top-0 right-0 -translate-y-12 translate-x-1/3 w-96 h-96 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 translate-y-1/3 -translate-x-1/3 w-96 h-96 bg-accent/30 rounded-full blur-3xl pointer-events-none" />
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">How it works</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">Three simple steps to decode your lab results.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto relative">
            {/* Connecting line for desktop */}
            <div className="hidden md:block absolute top-1/2 left-0 w-full h-0.5 bg-border -translate-y-1/2 z-0" />
            
            <div className="relative z-10 flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-background border-4 border-muted flex items-center justify-center mb-6 shadow-sm">
                <Upload className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">1. Upload Results</h3>
              <p className="text-muted-foreground text-sm">Enter your values manually or upload your PDF/Image report directly.</p>
            </div>
            
            <div className="relative z-10 flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-primary border-4 border-primary-foreground flex items-center justify-center mb-6 shadow-md text-white">
                <Brain className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold mb-2">2. Smart Analysis</h3>
              <p className="text-muted-foreground text-sm">Our clinical engine cross-references your values with established hematology guidelines.</p>
            </div>
            
            <div className="relative z-10 flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-background border-4 border-muted flex items-center justify-center mb-6 shadow-sm">
                <FileText className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">3. Get Clarity</h3>
              <p className="text-muted-foreground text-sm">Receive a plain-English explanation, lifestyle tips, and questions for your doctor.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features/Benefits Section */}
      <section className="py-24 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center max-w-6xl mx-auto">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Designed for patients, grounded in science.</h2>
              <p className="text-lg text-muted-foreground mb-8">
                We bridge the gap between getting your lab results and discussing them with your doctor. Alleviate anxiety with knowledge.
              </p>
              
              <ul className="space-y-6">
                <li className="flex gap-4">
                  <div className="mt-1 w-6 h-6 rounded-full bg-primary/20 text-primary flex items-center justify-center shrink-0">
                    <CheckCircle className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg">Clear Explanations</h4>
                    <p className="text-muted-foreground">No medical jargon. We explain what each parameter does in simple terms.</p>
                  </div>
                </li>
                <li className="flex gap-4">
                  <div className="mt-1 w-6 h-6 rounded-full bg-primary/20 text-primary flex items-center justify-center shrink-0">
                    <CheckCircle className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg">Correlated Analysis</h4>
                    <p className="text-muted-foreground">We don't just look at values in isolation. We analyze patterns (like low MCV + low Hb).</p>
                  </div>
                </li>
                <li className="flex gap-4">
                  <div className="mt-1 w-6 h-6 rounded-full bg-primary/20 text-primary flex items-center justify-center shrink-0">
                    <CheckCircle className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg">Actionable Next Steps</h4>
                    <p className="text-muted-foreground">Get personalized lifestyle recommendations and specific questions to ask your physician.</p>
                  </div>
                </li>
              </ul>
            </div>
            
            <div className="relative">
              <div className="aspect-[4/5] md:aspect-square rounded-2xl bg-gradient-to-br from-primary/10 to-accent/30 overflow-hidden border border-border/50 shadow-xl flex items-center justify-center p-8">
                <Card className="w-full shadow-2xl border-none">
                  <CardContent className="p-6 space-y-4">
                    <div className="flex justify-between items-center border-b pb-4">
                      <div className="font-semibold">MCHC</div>
                      <div className="flex gap-3 items-center">
                        <span className="font-mono text-lg font-bold">31.5</span>
                        <span className="px-2 py-1 bg-yellow-100 dark:bg-yellow-900/50 text-yellow-800 dark:text-yellow-400 text-xs rounded font-medium">Low</span>
                      </div>
                    </div>
                    <p className="text-sm">Your MCHC is slightly below the normal range. This indicates that your red blood cells have less hemoglobin than usual, which can make them appear paler under a microscope. When seen alongside a low MCV, this is often associated with iron deficiency.</p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Parameters Section */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Comprehensive Coverage</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Our engine analyzes all standard complete blood count parameters.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 max-w-6xl mx-auto">
            {PARAMETERS.map((param, index) => (
              <Card key={index} className="border-border/60 shadow-sm hover:shadow-md transition-all hover:border-primary/30 group">
                <CardContent className="p-5">
                  <h3 className="font-semibold text-base mb-1 group-hover:text-primary transition-colors">{param.name}</h3>
                  <p className="text-xs text-muted-foreground mb-3">{param.purpose}</p>
                  <div className="text-xs font-mono bg-muted p-2 rounded">{param.range}</div>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="text-center mt-12">
            <Link href="/analyzer">
              <Button variant="link" className="text-primary text-base">
                Explore all parameters <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24 bg-muted/30">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
          </div>
          <Accordion type="single" collapsible className="w-full bg-background rounded-lg border px-4 shadow-sm">
            <AccordionItem value="item-1">
              <AccordionTrigger className="text-left font-medium">Is this a replacement for my doctor?</AccordionTrigger>
              <AccordionContent className="text-muted-foreground leading-relaxed">
                Absolutely not. This tool is designed to help you understand the terminology and standard implications of your CBC report so you can have a more informed conversation with your physician. It does not provide diagnoses.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-2">
              <AccordionTrigger className="text-left font-medium">How accurate is the interpretation?</AccordionTrigger>
              <AccordionContent className="text-muted-foreground leading-relaxed">
                Our engine uses established clinical hematology guidelines to explain what values typically mean. However, clinical context — your symptoms, medical history, and physical findings — is required for true accuracy, which only your doctor can provide.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-3">
              <AccordionTrigger className="text-left font-medium">Do you save my medical data?</AccordionTrigger>
              <AccordionContent className="text-muted-foreground leading-relaxed">
                No. Your data is processed for the interpretation and immediately discarded. We do not store your personal lab values or build profiles around your health data.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-4">
              <AccordionTrigger className="text-left font-medium">Why is a parameter flagged as abnormal here but normal on my report?</AccordionTrigger>
              <AccordionContent className="text-muted-foreground leading-relaxed">
                Different laboratories sometimes use slightly different reference ranges based on their specific equipment or local populations. You should always defer to the reference ranges printed on your specific lab report.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-24 bg-primary text-primary-foreground relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-white via-transparent to-transparent" />
        <div className="container mx-auto px-4 relative z-10 text-center max-w-3xl">
          <HeartPulse className="w-12 h-12 mx-auto mb-6 opacity-80" />
          <h2 className="text-3xl md:text-5xl font-bold mb-6">Stop wondering. Start understanding.</h2>
          <p className="text-lg md:text-xl opacity-90 mb-10">
            Get your smart CBC interpretation in seconds.
          </p>
          <Link href="/analyzer">
            <Button size="lg" variant="secondary" className="text-lg h-14 px-10 text-primary hover:bg-white">
              Analyze Report Now
            </Button>
          </Link>
        </div>
      </section>
    </AppLayout>
  );
}
