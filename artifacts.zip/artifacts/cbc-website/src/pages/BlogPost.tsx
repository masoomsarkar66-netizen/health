import { AppLayout } from "@/components/layout/AppLayout";
import { SEOHead } from "@/components/SEOHead";
import { useGetBlogPost, getGetBlogPostQueryKey } from "@workspace/api-client-react";
import { useParams, Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, ChevronLeft, User } from "lucide-react";
import { format } from "date-fns";

export default function BlogPost() {
  const params = useParams();
  // Extract ID from slug format: "123-title-of-post"
  const idMatch = params.slug?.match(/^(\d+)-/);
  const postId = idMatch ? parseInt(idMatch[1], 10) : 0;

  const { data: post, isLoading } = useGetBlogPost(postId, { 
    query: { 
      enabled: !!postId,
      queryKey: getGetBlogPostQueryKey(postId)
    } 
  });

  if (isLoading) {
    return (
      <AppLayout>
        <div className="container mx-auto px-4 py-12 max-w-3xl">
          <Skeleton className="w-24 h-10 mb-8" />
          <Skeleton className="w-32 h-6 mb-4" />
          <Skeleton className="w-full h-12 mb-4" />
          <Skeleton className="w-2/3 h-12 mb-8" />
          <div className="flex gap-4 mb-12">
            <Skeleton className="w-32 h-6" />
            <Skeleton className="w-32 h-6" />
          </div>
          <div className="space-y-4">
            <Skeleton className="w-full h-4" />
            <Skeleton className="w-full h-4" />
            <Skeleton className="w-full h-4" />
            <Skeleton className="w-5/6 h-4" />
          </div>
        </div>
      </AppLayout>
    );
  }

  if (!post && !isLoading) {
    return (
      <AppLayout>
        <div className="container mx-auto px-4 py-24 text-center">
          <h1 className="text-3xl font-bold mb-4">Post Not Found</h1>
          <p className="text-muted-foreground mb-8">The article you're looking for doesn't exist or has been removed.</p>
          <Link href="/blog">
            <Button>Back to Blog</Button>
          </Link>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <SEOHead
        title={post?.title ?? "Health Article"}
        description={post?.excerpt ?? "Read this health article on CBCLab.ai — expert hematology and blood test education."}
        canonical={`/blog/${params.slug}`}
        ogType="article"
        publishedTime={post?.createdAt}
        author={post?.author ?? undefined}
        keywords={post?.tags ?? undefined}
      />
      <article className="pb-24">
        {/* Header */}
        <div className="bg-muted/30 pt-12 pb-16 border-b">
          <div className="container mx-auto px-4 max-w-3xl">
            <Link href="/blog">
              <Button variant="ghost" className="mb-8 pl-0 text-muted-foreground hover:text-foreground">
                <ChevronLeft className="w-4 h-4 mr-2" /> Back to all articles
              </Button>
            </Link>
            
            <Badge className="mb-6">{post?.category}</Badge>
            
            <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
              {post?.title}
            </h1>
            
            <p className="text-xl text-muted-foreground mb-8">
              {post?.excerpt}
            </p>
            
            <div className="flex flex-wrap items-center gap-6 text-sm text-muted-foreground border-t pt-6">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4" />
                <span className="font-medium text-foreground">{post?.author}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                <span>{post && format(new Date(post.createdAt), "MMMM d, yyyy")}</span>
              </div>
              {post?.readTimeMinutes && (
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  <span>{post.readTimeMinutes} min read</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="container mx-auto px-4 py-12 max-w-3xl">
          <div 
            className="prose prose-slate dark:prose-invert max-w-none prose-headings:text-foreground prose-a:text-primary hover:prose-a:text-primary/80 prose-img:rounded-xl"
            dangerouslySetInnerHTML={{ __html: post?.content || "" }}
          />
          
          {post?.tags && (
            <div className="mt-12 pt-8 border-t">
              <h3 className="font-semibold mb-4 text-sm uppercase tracking-wider text-muted-foreground">Tags</h3>
              <div className="flex flex-wrap gap-2">
                {post.tags.split(',').map(tag => (
                  <Badge key={tag.trim()} variant="secondary" className="font-normal">
                    {tag.trim()}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </div>
      </article>
    </AppLayout>
  );
}
