import { SEOHead } from "@/components/SEOHead";

export default function PrivacyPolicy() {
  return (
    <>
      <SEOHead
        title="Privacy Policy — CBCLab.ai"
        description="Read the CBCLab.ai privacy policy. Learn how we collect, use, and protect your information when you use our CBC blood test interpretation platform."
        canonical="/privacy"
        noIndex={false}
      />
      <main className="container mx-auto px-4 py-12 max-w-3xl">
        <h1 className="text-3xl font-bold mb-2">Privacy Policy</h1>
        <p className="text-muted-foreground text-sm mb-10">Last updated: June 23, 2026</p>

        <section className="prose prose-neutral dark:prose-invert max-w-none space-y-8 text-sm leading-7">

          <div>
            <h2 className="text-xl font-semibold mb-3">1. Introduction</h2>
            <p>
              Welcome to <strong>CBCLab.ai</strong> ("we", "our", or "us"). We are committed to protecting
              your personal information and your right to privacy. This Privacy Policy explains what
              information we collect, how we use it, and what rights you have in relation to it when
              you visit our website and use our CBC blood test interpretation service (the "Service").
            </p>
            <p className="mt-3">
              Please read this policy carefully. If you disagree with its terms, please discontinue
              use of the Service.
            </p>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-3">2. Information We Collect</h2>
            <h3 className="font-semibold mb-2">a) Information You Provide Directly</h3>
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>CBC values you enter</strong> when using the Analyzer tool (e.g. hemoglobin, WBC, platelets)</li>
              <li><strong>Contact form submissions</strong> including your name, email address, and message content</li>
              <li>Any other information you voluntarily provide when contacting us</li>
            </ul>
            <h3 className="font-semibold mb-2 mt-4">b) Information Collected Automatically</h3>
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>Usage data</strong> — pages visited, time spent on pages, referring URL</li>
              <li><strong>Device information</strong> — browser type, operating system, screen resolution</li>
              <li><strong>IP address</strong> — used for analytics and abuse prevention, not linked to your identity</li>
              <li><strong>Cookies and local storage</strong> — used to remember your theme preference (light/dark mode)</li>
            </ul>
            <h3 className="font-semibold mb-2 mt-4">c) Health-Related Input Data</h3>
            <p>
              When you use the CBC Analyzer, the numerical values you enter are processed to generate
              an interpretation. We store anonymized versions of these results to improve our service
              and for aggregate analytics. We do <strong>not</strong> link this data to your identity unless you
              explicitly provide identifying information alongside it.
            </p>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-3">3. How We Use Your Information</h2>
            <p>We use the information we collect to:</p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>Provide, operate, and maintain the Service</li>
              <li>Generate CBC interpretations using our clinical engine</li>
              <li>Respond to your contact form submissions and support requests</li>
              <li>Analyze usage patterns to improve the platform</li>
              <li>Detect and prevent fraudulent or abusive use</li>
              <li>Send you updates or notifications if you have opted in</li>
              <li>Comply with applicable legal obligations</li>
            </ul>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-3">4. Sharing of Your Information</h2>
            <p>
              We do <strong>not</strong> sell, trade, or rent your personal information to third parties. We may
              share information in the following limited circumstances:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>
                <strong>Service providers:</strong> Trusted third-party vendors who assist us in operating
                the website (e.g. hosting, analytics). They are contractually obligated to keep your
                data confidential.
              </li>
              <li>
                <strong>AI processing:</strong> CBC values you enter are sent to an AI model API (OpenAI)
                for interpretation. This transmission is encrypted and subject to OpenAI's data
                processing terms.
              </li>
              <li>
                <strong>Legal requirements:</strong> We may disclose your information if required by law,
                court order, or governmental authority.
              </li>
              <li>
                <strong>Business transfers:</strong> In the event of a merger or acquisition, your
                information may be transferred to the successor entity.
              </li>
            </ul>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-3">5. Cookies and Tracking Technologies</h2>
            <p>
              We use minimal cookies and browser local storage primarily for:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>Remembering your dark/light mode preference</li>
              <li>Basic session management</li>
              <li>Anonymous analytics (aggregated, non-identifying)</li>
            </ul>
            <p className="mt-3">
              You can control or delete cookies through your browser settings. Disabling cookies
              may affect some features of the Service.
            </p>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-3">6. Data Retention</h2>
            <p>
              We retain your personal information only for as long as necessary to fulfill the
              purposes outlined in this policy. Contact form submissions are retained for up to
              12 months. Anonymized CBC analysis data may be retained indefinitely for aggregate
              research and service improvement purposes.
            </p>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-3">7. Data Security</h2>
            <p>
              We implement industry-standard security measures to protect your information,
              including HTTPS encryption for all data in transit and secure server infrastructure.
              However, no method of transmission over the internet is 100% secure, and we cannot
              guarantee absolute security.
            </p>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-3">8. Children's Privacy</h2>
            <p>
              Our Service is not directed to children under the age of 13. We do not knowingly
              collect personal information from children under 13. If you believe we have
              inadvertently collected such information, please contact us immediately and we
              will take steps to delete it.
            </p>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-3">9. Your Rights</h2>
            <p>Depending on your location, you may have the right to:</p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>Access the personal information we hold about you</li>
              <li>Request correction of inaccurate data</li>
              <li>Request deletion of your personal data</li>
              <li>Object to or restrict our processing of your data</li>
              <li>Data portability (receive your data in a portable format)</li>
              <li>Withdraw consent at any time where processing is based on consent</li>
            </ul>
            <p className="mt-3">
              To exercise any of these rights, contact us at{" "}
              <a href="mailto:support@cbclab.ai" className="text-primary hover:underline">
                support@cbclab.ai
              </a>.
            </p>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-3">10. Third-Party Links</h2>
            <p>
              Our website may contain links to third-party websites. We are not responsible for
              the privacy practices or content of those sites. We encourage you to review their
              privacy policies before providing any personal information.
            </p>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-3">11. Changes to This Policy</h2>
            <p>
              We may update this Privacy Policy from time to time. When we do, we will revise the
              "Last updated" date at the top of this page. We encourage you to review this policy
              periodically. Continued use of the Service after changes constitutes acceptance of
              the updated policy.
            </p>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-3">12. Contact Us</h2>
            <p>
              If you have questions or concerns about this Privacy Policy, please contact us:
            </p>
            <ul className="list-none mt-2 space-y-1">
              <li>
                <strong>Email:</strong>{" "}
                <a href="mailto:support@cbclab.ai" className="text-primary hover:underline">
                  support@cbclab.ai
                </a>
              </li>
              <li><strong>Website:</strong> cbclab.ai</li>
            </ul>
          </div>

        </section>
      </main>
    </>
  );
}
