import { AppLayout } from "@/components/layout/AppLayout";
import { SEOHead } from "@/components/SEOHead";
import { Card, CardContent } from "@/components/ui/card";
import { ShieldAlert } from "lucide-react";

export default function Disclaimer() {
  return (
    <AppLayout>
      <SEOHead
        title="Medical Disclaimer — CBCLab.ai"
        description="Important medical disclaimer for CBCLab.ai. This platform is for educational purposes only and does not constitute medical advice, diagnosis, or treatment."
        canonical="/disclaimer"
        noIndex={false}
      />
      <div className="container mx-auto px-4 py-16 md:py-24 max-w-3xl">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-destructive/10 text-destructive mb-6">
            <ShieldAlert className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold mb-4">Medical Disclaimer</h1>
          <p className="text-xl text-muted-foreground">
            Please read this information carefully before using our platform.
          </p>
        </div>

        <Card>
          <CardContent className="p-8 prose prose-slate dark:prose-invert max-w-none">
            <h3>1. Not Medical Advice</h3>
            <p>
              The CBCLab.ai (the "Service") is provided for educational and informational 
              purposes only. It does not constitute medical advice, diagnosis, or treatment. Always seek 
              the advice of your physician or other qualified health provider with any questions you may 
              have regarding a medical condition or your test results.
            </p>

            <h3>2. No Doctor-Patient Relationship</h3>
            <p>
              Use of this Service does not create a doctor-patient relationship between you and CBCLab.ai, 
              its creators, or any affiliated medical professionals. The information provided by the platform 
              is generated based on general medical knowledge and clinical guidelines, and should not replace 
              professional medical judgment.
            </p>

            <h3>3. Accuracy and Limitations</h3>
            <p>
              While we strive to provide accurate interpretations based on standard hematological guidelines, 
              automated systems can make mistakes. The system does not have access to your full medical history, 
              symptoms, physical examination findings, or other laboratory tests, all of which are essential 
              for an accurate diagnosis. A normal CBC result does not guarantee that you are healthy, and 
              an abnormal result does not necessarily indicate a disease.
            </p>

            <h3>4. Medical Emergencies</h3>
            <p>
              If you think you may have a medical emergency, call your doctor, go to the emergency department, 
              or call emergency services immediately. Do not rely on this Service for urgent medical needs.
            </p>

            <h3>5. Never Delay Treatment</h3>
            <p>
              Never disregard professional medical advice or delay in seeking it because of something you 
              have read on this Service.
            </p>

            <div className="mt-8 p-4 bg-muted rounded-lg border">
              <p className="text-sm m-0 font-medium text-foreground">
                By using the CBCLab.ai, you acknowledge that you have read, understood, 
                and agree to this disclaimer.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
