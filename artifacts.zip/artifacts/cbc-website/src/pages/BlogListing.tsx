import { AppLayout } from "@/components/layout/AppLayout";
import { SEOHead } from "@/components/SEOHead";
import { useGetBlogPosts, getGetBlogPostsQueryKey } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Search, Calendar } from "lucide-react";
import { useState } from "react";
import { format } from "date-fns";

export default function BlogListing() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<string | undefined>();
  
  const { data, isLoading } = useGetBlogPosts(
    { search: search || undefined, category },
    { query: { queryKey: getGetBlogPostsQueryKey({ search: search || undefined, category }) } }
  );

  return (
    <AppLayout>
      <SEOHead
        title="Health Insights Blog — CBC & Hematology Articles"
        description="Expert articles on CBC interpretation, hematology, anemia, blood disorders, and proactive health management. Understand your lab results with evidence-based content."
        canonical="/blog"
        keywords="CBC interpretation blog, hematology articles, anemia symptoms, blood disorders, low hemoglobin causes, high WBC meaning, blood test education"
      />
      <div className="bg-primary/5 py-16 md:py-24 border-b">
        <div className="container mx-auto px-4 text-center max-w-3xl">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Health Insights</h1>
          <p className="text-xl text-muted-foreground mb-8">
            Expert articles on hematology, understanding lab results, and proactive health management.
          </p>
          <div className="relative max-w-xl mx-auto">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
            <Input 
              type="search" 
              placeholder="Search articles..." 
              className="pl-10 h-12 text-base bg-background"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16">
        <div className="flex flex-wrap gap-2 mb-12 justify-center">
          <Badge 
            variant={!category ? "default" : "outline"} 
            className="cursor-pointer text-sm py-1.5 px-4"
            onClick={() => setCategory(undefined)}
          >
            All Topics
          </Badge>
          {["Hematology", "CBC Interpretation", "Anemia", "Blood Disorders"].map(cat => (
            <Badge 
              key={cat}
              variant={category === cat ? "default" : "outline"} 
              className="cursor-pointer text-sm py-1.5 px-4"
              onClick={() => setCategory(cat)}
            >
              {cat}
            </Badge>
          ))}
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <Card key={i} className="overflow-hidden">
                <Skeleton className="h-48 w-full rounded-none" />
                <CardHeader>
                  <Skeleton className="h-4 w-24 mb-2" />
                  <Skeleton className="h-6 w-full" />
                  <Skeleton className="h-6 w-2/3" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-2/3" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : data?.posts.length === 0 ? (
          <div className="text-center py-20">
            <h3 className="text-2xl font-semibold mb-2">No articles found</h3>
            <p className="text-muted-foreground">Try adjusting your search or category filter.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {data?.posts.map(post => (
              <Link key={post.id} href={`/blog/${post.id}-${post.slug}`}>
                <Card className="h-full hover:shadow-md transition-shadow cursor-pointer border-border/50 group">
                  <div className="h-48 bg-muted flex items-center justify-center overflow-hidden">
                    <div className="w-full h-full bg-gradient-to-br from-primary/20 to-primary/5 group-hover:scale-105 transition-transform duration-500" />
                  </div>
                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="secondary" className="font-normal text-primary">
                        {post.category}
                      </Badge>
                      {post.readTimeMinutes && (
                        <span className="text-xs text-muted-foreground">{post.readTimeMinutes} min read</span>
                      )}
                    </div>
                    <h3 className="text-xl font-semibold line-clamp-2 group-hover:text-primary transition-colors">
                      {post.title}
                    </h3>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground line-clamp-3">
                      {post.excerpt}
                    </p>
                  </CardContent>
                  <CardFooter className="pt-0 flex items-center gap-4 text-sm text-muted-foreground border-t mt-auto px-6 py-4">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      <span>{format(new Date(post.createdAt), "MMM d, yyyy")}</span>
                    </div>
                  </CardFooter>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
