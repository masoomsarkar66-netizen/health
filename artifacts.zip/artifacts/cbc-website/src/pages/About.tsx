import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, Lightbulb, Users, Activity } from "lucide-react";
import { SEOHead } from "@/components/SEOHead";

export default function About() {
  return (
    <AppLayout>
      <SEOHead
        title="About CBCLab.ai — Our Mission & Approach"
        description="Learn how CBCLab.ai bridges the gap between complex lab results and patient understanding. Built on standard hematology guidelines, designed for patient empowerment."
        canonical="/about"
        keywords="about CBC insight, hematology guidelines, patient empowerment, blood test education, lab report explained, evidence-based healthcare"
      />
      <div className="container mx-auto px-4 py-16 md:py-24 max-w-4xl">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 tracking-tight">Our Mission</h1>
          <p className="text-xl text-muted-foreground leading-relaxed">
            To make medical data accessible, understandable, and empowering for everyone. 
            We believe that understanding your health shouldn't require a medical degree.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <Card className="bg-primary/5 border-primary/10">
            <CardContent className="p-8">
              <Lightbulb className="w-10 h-10 text-primary mb-4" />
              <h3 className="text-2xl font-semibold mb-3">The Problem</h3>
              <p className="text-muted-foreground">
                Lab reports are written for doctors, not patients. When you receive your CBC results, 
                you're often left with confusing numbers, terrifying acronyms, and out-of-context "high" or "low" markers 
                that cause unnecessary anxiety before your follow-up appointment.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-primary/5 border-primary/10">
            <CardContent className="p-8">
              <Shield className="w-10 h-10 text-primary mb-4" />
              <h3 className="text-2xl font-semibold mb-3">Our Solution</h3>
              <p className="text-muted-foreground">
                We combine advanced clinical analytics with established hematology guidelines to translate complex 
                lab values into clear, actionable insights. We bridge the gap between getting your 
                results and speaking with your physician.
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="prose prose-slate dark:prose-invert max-w-none mb-16">
          <h2 className="text-3xl font-bold mb-6">Smart Analytics meets Lab Science</h2>
          <p>
            Our interpretation engine is built on the intersection of advanced computational analysis 
            and rigorous clinical guidelines. When you input your CBC parameters, the system doesn't just 
            flag what's abnormal — it analyzes the relationships between different markers.
          </p>
          <p>
            For example, a high MCV (Mean Corpuscular Volume) means something very different depending on 
            your Hemoglobin and B12 levels. Our engine understands these clinical correlations and explains 
            them in plain English, helping you ask better questions when you see your doctor.
          </p>
        </div>

        <div className="border-t pt-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Built on Trust</h2>
            <p className="text-muted-foreground">We take your health data seriously.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
            <div>
              <div className="w-16 h-16 mx-auto bg-muted rounded-full flex items-center justify-center mb-4">
                <Shield className="w-8 h-8 text-primary" />
              </div>
              <h4 className="font-semibold mb-2">Privacy First</h4>
              <p className="text-sm text-muted-foreground">We don't store your personal health data after analysis is complete.</p>
            </div>
            <div>
              <div className="w-16 h-16 mx-auto bg-muted rounded-full flex items-center justify-center mb-4">
                <Activity className="w-8 h-8 text-primary" />
              </div>
              <h4 className="font-semibold mb-2">Evidence Based</h4>
              <p className="text-sm text-muted-foreground">Interpretations are grounded in standard clinical hematology guidelines.</p>
            </div>
            <div>
              <div className="w-16 h-16 mx-auto bg-muted rounded-full flex items-center justify-center mb-4">
                <Users className="w-8 h-8 text-primary" />
              </div>
              <h4 className="font-semibold mb-2">Patient Centric</h4>
              <p className="text-sm text-muted-foreground">Designed specifically to empower patients, not replace doctors.</p>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
